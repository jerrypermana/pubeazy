</br>
</br>
<main id="main">

    <!--==========================
      Speaker Details Section
    ============================-->
    <section id="speakers-details" class="wow fadeIn">
        <div class="container">
            <div class="section-header">
                <h2>REGISTRATION </h2>
                <p>Praesentium ut qui possimus sapiente nulla.</p>
            </div>

            <div class="row">

                <div class="col-md-12">
                    <section id="contact" class="section-bg wow fadeInUp">

                        <div class="container">

                            <div class="form">
                                <div id="sendmessage">Your message has been sent. Thank you!</div>
                                <div id="errormessage"></div>


                                <form role="form" action="" method="POST" name='simpan' class='form-horizontal form-bordered' onSubmit='return validasi()' enctype="multipart/form-data">


                                    <div class="col-md-12">

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="nama" class="form-control" id="name" placeholder="Nama Lengkap Tanpa Gelar" />
                                                <div class="validation"></div>

                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email"/>
                                                <div class="validation"></div>
                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="afiliasi" class="form-control" id="afiliasi" placeholder="Afiliasi" />
                                                <div class="validation"></div>

                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="negara_afiliasi" class="form-control" id="negara_afiliasi" placeholder="Negara Afiliasi" />
                                                <div class="validation"></div>
                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-8">
                                                <input type="text" name="alamat_afiliasi" class="form-control" id="alamat_afiliasi" placeholder="Alamat Afiliasi" />
                                                <div class="validation"></div>

                                            </div>

                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-8">
                                                <input type="text" name="url_orcid" class="form-control" id="url_orcid" placeholder="URL Orcid" />


                                            </div>

                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-8">
                                                <input type="text" name="url_profil" class="form-control" id="url_profil" placeholder="URL Profil" />
                                                <div class="validation"></div>

                                            </div>

                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="username" class="form-control" id="username" placeholder="Username" />
                                                <div class="validation"></div>

                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="hp" class="form-control" id="hp" placeholder="No Handphone" />
                                                <div class="validation"></div>
                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="password" name="password" class="form-control" id="password" placeholder="Password" />
                                                <div class="validation"></div>

                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="password" name="repassword" class="form-control" id="repassword" placeholder="Ulangi Password" />
                                                <div class="validation"></div>

                                            </div>
                                            <div class="col-md-2">
                                                <label></label>
                                            </div>
                                        </div>

                                        <div class="text-center">
                                            <button type="submit" name='submit'> Simpan</button>
                                        </div>
                                    </div>

                                </form>
                                <script type='text/javascript'>
                                    function validasi() {


                                        if (simpan.username.value == "") {
                                            alert("Username Tidak Boleh KOSONG ");
                                            simpan.username.focus();
                                            return false;
                                        }
                                        if (simpan.nama.value == "") {
                                            alert("Nama Tidak Boleh KOSONG");
                                            simpan.nama.focus();
                                            return false;
                                        }
                                        if (isNaN(parseInt(simpan.nama.value)) == false) {
                                            alert("Nama harus berisi HURUF");
                                            simpan.nama.focus();
                                            return false;
                                        }

                                        // var emailExp = /^[^\s()<>@,;:\/]+@\w[\w\.-]+\.[a-z]{2,}$/i;

                                        // if (!emailExp(simpan.email.value)) == false) {
                                        //     alert("Nama harus berisi HURUF");
                                        //     simpan.email.focus();
                                        //     return false;
                                        // }

                                        if (simpan.afiliasi.value == "") {
                                            alert("Afiliasi Tidak Boleh KOSONG");
                                            simpan.afiliasi.focus();
                                            return false;
                                        }
                                        if (simpan.negara_afiliasi.value == "") {
                                            alert("Negara Afiliasi Tidak Boleh KOSONG");
                                            simpan.negara_afiliasi.focus();
                                            return false;
                                        }
                                        if (simpan.alamat_afiliasi.value == "") {
                                            alert("Alamat Afiliasi Tidak Boleh KOSONG");
                                            simpan.alamat_afiliasi.focus();
                                            return false;
                                        }
                                        if (simpan.url_profil.value == "") {
                                            alert("URL Profil Tidak Boleh KOSONG");
                                            simpan.url_profil.focus();
                                            return false;
                                        }
                                        if (simpan.hp.value == "") {
                                            alert("No Handphone Tidak Boleh KOSONG");
                                            simpan.hp.focus();
                                            return false;
                                        }
                                        if (simpan.password.value == "") {
                                            alert("Password Tidak Boleh KOSONG");
                                            simpan.password.focus();
                                            return false;
                                        }

                                        var baru = simpan.password.value;
                                        var lagi = simpan.repassword.value;

                                        if (baru != lagi) {
                                            alert('Password baru tidak cocok,\nCek ulang password baru Anda!');
                                            return false;
                                        }


                                        return true;
                                    }
                                </script>
                            </div>
                            <?php


                            //  INSERT TO DATABASE REGISTER
                            if (isset($_POST['submit'])) {

                              $username         = $_POST['username'];
                              $nama             = ucwords($_POST['nama']);
                              $afiliasi         = ucwords($_POST['afiliasi']);
                              $negara           = $_POST['negara_afiliasi'] == '' ? '-' : ucwords($_POST['negara_afiliasi']);
                              $alamat           = $_POST['alamat_afiliasi'] == '' ? '-' : ucwords($_POST['alamat_afiliasi']);
                              $url_orcid        = $_POST['url_orcid'] == '' ? '-' : $_POST['url_orcid'];
                              $url_profil       = $_POST['url_profil'] == '' ? '-' : $_POST['url_profil'];
                              $email            = $_POST['email'] == '' ? '-' : $_POST['email'];
                              $hp               = $_POST['hp'] == '' ? '-' : $_POST['hp'];
                              $password         = md5($_POST['password']);
                              $tglinput         = date("Y/m/d");
                              $tglubah          = date("Y/m/d");
                              $image            = '-';
                              $group            = 'presenter';

                              $query  = "INSERT INTO presenter (username, realname, email, afiliasi, negara_afiliasi, alamat_afiliasi, url_orcid, url_profil,
                              no_hp, image, password, group_Session , input_date, last_update)
                              VALUES('$username ', '$nama', '$email', '$afiliasi ','$negara ', '$alamat', '$url_orcid', '$url_profil', '$hp', '$image','$password','$group','$tglinput', '$tglubah')";
                             
                              $insert_register = mysqli_query($konek, $query);
                           
                              if ($insert_register ) {
                                echo '<script>alert("Registrasi Berhasil")
			                        	location.replace("' . $base_url . '/url.php?p=login")</script>';
                              } else {

                                echo '<script>alert("Registrasi Gagal")
				                        location.replace("' . $base_url . '/url.php?p=register")</script>';
                              }
                            }
                            ?>

                        </div>
                    </section><!-- #contact -->
                </div>

            </div>
        </div>

    </section>

</main> 