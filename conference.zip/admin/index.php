<!DOCTYPE html>



<!-- end menu BAR-->

<!--  body -->
<?php
$domain = $_SERVER['SERVER_NAME'];
$base_url = "http://" . $domain . "/conference/admin";
include "header.php";
if (isset($_GET["p"])) {
    $id = $_GET["p"];

    if ($id == "dashboard") {
        include 'dashboard.php';
      } else {
      include 'index.php';
    }
  }
include "footer.php"
?>
<!-- End  body -->


<!-- CONTENT-WRAPPER SECTION END--> 