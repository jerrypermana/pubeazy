<?php
			if($_SESSION['group_session']=='presenter' || $_SESSION['group_session']=='admin'){
			?>
<!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard
          </h1>
         
        </section>
</br>
<div class="row">
           
              <div class="box box-default">
                
				<div class="box-body">
                 
                  
				  </div><!-- /.box-body -->

              </div><!-- /.box -->
            </div><!-- /.col -->
				  </br>
				  </br>
		
</div>


		
		
		
<?php
}

?>

       