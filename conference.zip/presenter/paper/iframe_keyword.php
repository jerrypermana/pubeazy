<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>

<body>
    <?php
    include "../../config/koneksi.php";
    $query      = "SELECT * FROM paper_keyword order by paper_id asc";
    $hasil = mysqli_query($konek, $query);
  				
    while($row=mysqli_fetch_array($hasil)){	
        echo "<table>
        <tr>
            <td><button type='button' class='btn btn-block btn-danger'>Danger</button></td>
            <td>$row[keyword_id]</td>
            <td></td>
        </tr>
    </table>";
    }
    ?>
    
</body>

</html> 