<?php
if ($_SESSION['group_session'] == 'presenter') {
    ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Upload Paper
    </h1>

</section>
</br>
<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Quick Example</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- form start -->
                            <form role="form" action="" method="POST" name='simpan' class='form-horizontal form-bordered' onSubmit='return validasi()' enctype="multipart/form-data">


                                <table class="table table-condensed">
                                    <tr>
                                        <th style="width: 20%; text-align: right;"><label>Judul*<label></th>
                                        <th style="width: 2%">:</th>
                                        <th style="width: 78%"><input type="text" name="judul" id='judul' class="form-control" style="width: 90%"></th>
                                    </tr>
                                    <tr>
                                        <th style="width: 20%; text-align: right;"><label>abstrak<label></th>
                                        <th style="width: 2%">:</th>
                                        <th style="width: 78%">
                                            <textarea class="form-control" name="abstrak" id='abstrak' rows="5" style="width: 90%"></textarea>
                                        </th>
                                    </tr>

                                    <tr>
                                        <th style="width: 20%; text-align: right;"><label>Keyword<label></th>
                                        <th style="width: 2%">:</th>
                                        <th style="width: 78%;">
                                            <!-- <iframe id="iframeid" src='paper/iframe_keyword.php' width=90% height=60% scrolling="auto" frameborder="1"></iframe> -->
                                            <select class="form-control select2" name='keyword[]' style="width: 50%;">
                                            </select>

                                    </tr>
                                    <tr>
                                        <th style="width: 20%; text-align: right;"></th>
                                        <th style="width: 2%"></th>
                                        <th style="width: 78%;">
                                            <!-- <iframe id="iframeid" src='paper/iframe_keyword.php' width=90% height=60% scrolling="auto" frameborder="1"></iframe> -->
                                            <select class="form-control select2" name='keyword[]' style="width: 50%;">
                                            </select>

                                    </tr>
                                    <tr>
                                        <th style="width: 20%; text-align: right;"></th>
                                        <th style="width: 2%"></th>
                                        <th style="width: 78%;">
                                            <!-- <iframe id="iframeid" src='paper/iframe_keyword.php' width=90% height=60% scrolling="auto" frameborder="1"></iframe> -->
                                            <select class="form-control select2" name='keyword[]' style="width: 50%;">
                                            </select>

                                    </tr>

                                    <tr>
                                        <th style="width: 20%; text-align: right;"></th>
                                        <th style="width: 2%"></th>
                                        <th style="width: 78%;">
                                            <!-- <iframe id="iframeid" src='paper/iframe_keyword.php' width=90% height=60% scrolling="auto" frameborder="1"></iframe> -->
                                            <select class="form-control select2" name='keyword[]' style="width: 50%;">
                                            </select>

                                    </tr>

                                    <tr>
                                        <th style="width: 20%; text-align: right;"><label><label></th>
                                        <th style="width: 2%"></th>
                                        <th style="width: 78%">
                                            <button type="button" class="btn btn-primary" data-target="#ModalAdd" data-toggle="modal">Tambah Keyword</button></th>

                                    </tr>
                                    <tr>
                                        <th style="width: 20%; text-align: right;"><label>Unggah Paper<label></th>
                                        <th style="width: 2%">:</th>
                                        <th style="width: 78%; padding: 5px 20px;">
                                            <div class="form-group">
                                                <label for="exampleInputFile">Masukkan File Paper</label>
                                                &nbsp &nbsp <input type="file" name='file' id='file' id="exampleInputFile">
                                                <p class="help-block">Maximum 4 Mb.</p>
                                            </div>

                                        </th>
                                    </tr>
                                    <tr>
                                        <th style="width: 20%"></th>
                                        <th style="width: 2%"></th>
                                        <th style="width: 78%"> </br></br></br></th>
                                    </tr>
                                    <tr>
                                        <th colspan="3">
                                            <center>
                                                <button type="submit" name='submit' class="btn btn-block btn-primary btn-sm">Submit</button>
                                                <button type="reset" onclick="goBack()" class="btn btn-block btn-warning btn-sm">Cancel</button>
                                            </center>
                                        </th>
                                    </tr>

                                </table>
                            </form>
                            <?php
                            if (isset($_POST['submit'])) {

                                $judul      = ucwords($_POST['judul']);
                                $abstrak    = $_POST['abstrak'] == '' ? '-' : $_POST['abstrak'];
                                $username   = $_SESSION['username'];
                                $v_paper    = '0';
                                $loa        = '0';
                                $lol        = '0';
                                $tglinput = date('Y-m-d');
                                $tglubah = date('Y-m-d');

                                $ekstensi_diperbolehkan    = array('pdf');
                                $nama = $_FILES['file']['name'];
                                $x = explode('.', $nama);
                                $ekstensi = strtolower(end($x));
                                $ukuran    = $_FILES['file']['size'];
                                $file_tmp = $_FILES['file']['tmp_name'];


                                if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
                                    if ($ukuran < 4485760) {
                                        move_uploaded_file($file_tmp, '../repository/' . $nama);

                                        $query_paper  = "INSERT INTO paper (username, judul, abstrak, file_paper, v_paper, loa, lol, input_date, last_update)
                                        VALUES('$username ', '$judul', '$abstrak', '$nama','$v_paper', '$loa','$lol','$tglinput', '$tglubah')";

                                        $insert_paper = mysqli_query($konek, $query_paper);
                                        $keyword        = $_POST['keyword'];
                                        $jumlah_diisi   = count($keyword);

                                        $paper_id       = mysqli_insert_id($konek);

                                        for ($x = 0; $x < $jumlah_diisi; $x++) {

                                            $query_keyword  = "INSERT INTO paper_keyword values('$paper_id','$keyword[$x]')";
                                            $insert_keyword = mysqli_query($konek, $query_keyword);
                                        }


                                        if ($insert_paper and $query_keyword) {
                                            echo '<script>alert("Paper Berhasil di Tambahkan")</script>';
                                        } else {
                                            echo '<script>alert("Paper Gagal di Tambahkan")</script>';
                                        }
                                    } else {
                                        echo '<script>alert("Ukuran File Terlalu Besar")</script>';
                                    }
                                } else {
                                    echo '<script>alert("Ekstensi Yang Di Upload Tidak Diperbolehkan")</script>';
                                }
                            }

                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box -->


            <!-- /.box -->

            <!-- Input addon -->


        </div>
    </div>
    <!-- Modal -->
    <!-- Modal Popup untuk Add-->
    <div id="ModalAdd" name='myform' class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Tambahkan Keyword</h4>
                </div>

                <div class="modal-body">
                    <form id="add_keyword" method="POST">

                        <div class="form-group" style="padding-bottom: 20px;">
                            <label for="Modal Name">Keyword</label>
                            <input type="text" name="keyword" class="form-control" placeholder="Masukkan Nama Keyword ..." required />
                            <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>" />
                        </div>



                        <div class="modal-footer">
                            <button class="btn btn-success" id="btn" type="submit">
                                Confirm
                            </button>

                            <button type="button" class="btn btn-danger" data-dismiss="modal" aria-hidden="true" onclick="$('#add_keyword')[0].reset();">
                                Cancel
                            </button>
                        </div>

                    </form>



                </div>


            </div>
        </div>
    </div>
    <!-- TUTUP Modal -->
    <script>
        $(document).ready(function() {


            $('.select2').select2({
                minimumInputLength: 2,
                allowClear: true,
                placeholder: 'Search Keywords ...',
                ajax: {
                    url: 'data_api/ajax_select.php',
                    dataType: 'json',
                    data: function(params) {
                        var query = {
                            search: params.term,

                        }
                        // Query parameters will be ?search=[term]&type=public
                        return query;
                    }

                }

            });


        })
    </script>
    </div>
    </div>
    <?php 
}
?> 