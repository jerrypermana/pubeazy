<?php
if ($_SESSION['group_session'] == 'presenter') {
    ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Ubah Profil Pengguna
    </h1>

</section>

<?php

$username   = $_SESSION['username'];
$query      = "SELECT * FROM presenter WHERE username='$username'";
$hasil = mysqli_query($konek, $query);
$row = mysqli_fetch_array($hasil);
$hitung = mysqli_num_rows($hasil);

if ($hitung == 0) {
    echo '<script>alert("ID Anggota Tidak Di Temukan")
             location.replace("' . $base_url . '../index.php?id=dashboard")</script>';
}
?>
</br>
<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <!-- general form elements -->
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab_1" data-toggle="tab">
                            <h4 class="box-title">Ubah Profil Pengguna</h4>
                        </a></li>
                    <li><a href="#tab_2" data-toggle="tab">
                            <h4 class="box-title">Ubah Password Pengguna</h4>
                        </a></li>

                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1">
                        <form role="form" action="" method="POST" name='simpan' class='form-horizontal form-bordered' onSubmit='return validasi()' enctype="multipart/form-data">
                            <table class="table table-condensed">
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Username<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="username" id='username' class="form-control" style="width: 50%" value='<?php echo $row['username']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Nama Lengkap<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="nama" id='nama' class="form-control" style="width: 50%" value='<?php echo $row['realname']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Email<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="email" id='email' class="form-control" style="width: 50%" value='<?php echo $row['email']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Afiliasi<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="afiliasi" id='afiliasi' class="form-control" style="width: 50%" value='<?php echo $row['afiliasi']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Negara Afiliasi<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="negara_afiliasi" id='negara_afiliasi' class="form-control" style="width: 30%" value='<?php echo $row['negara_afiliasi']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Alamat<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%">
                                        <textarea class="form-control" name="alamat_afiliasi" id='alamat_afiliasi' rows="2" style="width: 90%"><?php echo $row['alamat_afiliasi']; ?></textarea>
                                    </th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>URL Orcid<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="url_orcid" id='url_orcid' class="form-control" style="width: 90%" value='<?php echo $row['url_orcid']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>URL Profil<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="url_profil" id='url_profil' class="form-control" style="width: 90%" value='<?php echo $row['url_profil']; ?>'></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>No Handphone<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="text" name="hp" id='hp' class="form-control" style="width: 30%" value='<?php echo $row['no_hp']; ?>'></th>
                                </tr>



                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Unggah Foto Profil<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%; padding: 5px 20px;">
                                        <div class="form-group">
                                            <label for="exampleInputFile">Masukkan Foto Profil</label>
                                            &nbsp &nbsp <input type="file" name='image' id='image' id="exampleInputFile">
                                            <p class="help-block">Maximum 1 Mb.</p>
                                        </div>

                                    </th>
                                </tr>


                                <tr>
                                    <th colspan="3">
                                        <center>
                                            <button type="submit" name='update' class="btn btn-block btn-primary btn-sm">Submit</button>
                                            <button type="reset" onclick="goBack()" class="btn btn-block btn-warning btn-sm">Cancel</button>
                                        </center>
                                    </th>
                                </tr>

                            </table>
                        </form>
                    </div>
                    <!-- /.tab-pane -->
                    <div class="tab-pane" id="tab_2">
                        <form role="form" action="" method="POST" name='simpan_pass' class='form-horizontal form-bordered' onSubmit='return validasi()' enctype="multipart/form-data">
                            <table class="table table-condensed">
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Password<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="password" name="password" id='password' class="form-control" style="width: 30%"></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%; text-align: right;"><label>Ulangi Password<label></th>
                                    <th style="width: 2%">:</th>
                                    <th style="width: 78%"><input type="password" name="repassword" id='repassword' class="form-control" style="width: 30%"></th>
                                </tr>
                                <tr>
                                    <th style="width: 20%"></th>
                                    <th style="width: 2%"></th>
                                    <th style="width: 78%"> </br></br></br></th>
                                </tr>
                                <tr>
                                    <th colspan="3">
                                        <center>
                                            <button type="submit" name='update_pass' class="btn btn-block btn-primary btn-sm">Submit</button>
                                            <button type="reset" onclick="goBack()" class="btn btn-block btn-warning btn-sm">Cancel</button>
                                        </center>
                                    </th>
                                </tr>
                            </table>
                        </form>
                    </div>
                    <!-- /.tab-pane -->
                    <div class="tab-pane" id="tab_3">

                    </div>
                    <!-- /.tab-pane -->
                </div>
                <!-- /.AKHIR -->
            </div>

            <!-- /.box-header -->
            <!-- form start -->
            <f <!-- SCRIPT VALIDASI FORM EDIT TABEL -->
                <script type='text/javascript'>
                    function validasi() {


                        if (simpan.username.value == "") {
                            alert("Username Tidak Boleh KOSONG ");
                            simpan.username.focus();
                            return false;
                        }
                        if (simpan.nama.value == "") {
                            alert("Nama Tidak Boleh KOSONG");
                            simpan.nama.focus();
                            return false;
                        }
                        if (isNaN(parseInt(simpan.nama.value)) == false) {
                            alert("Nama harus berisi HURUF");
                            simpan.nama.focus();
                            return false;
                        }
                        if (simpan.afiliasi.value == "") {
                            alert("Afiliasi Tidak Boleh KOSONG");
                            simpan.afiliasi.focus();
                            return false;
                        }
                        if (simpan.negara_afiliasi.value == "") {
                            alert("Negara Afiliasi Tidak Boleh KOSONG");
                            simpan.negara_afiliasi.focus();
                            return false;
                        }
                        if (simpan.alamat_afiliasi.value == "") {
                            alert("Alamat Afiliasi Tidak Boleh KOSONG");
                            simpan.alamat_afiliasi.focus();
                            return false;
                        }
                        if (simpan.url_profil.value == "") {
                            alert("URL Profil Tidak Boleh KOSONG");
                            simpan.url_profil.focus();
                            return false;
                        }
                        if (simpan.hp.value == "") {
                            alert("No Handphone Tidak Boleh KOSONG");
                            simpan.hp.focus();
                            return false;
                        }

                        var baru = simpan_pass.password.value;
                        var lagi = simpan_pass.repassword.value;

                        if (baru != lagi) {
                            alert('Password baru tidak cocok,\nCek ulang password baru Anda!');
                            return false;
                        }


                        return true;
                    }
                </script>

                <!-- /.UPDATE DATA TABLE PRESENTER-->
                <?php

                if (isset($_POST['update'])) {
                    $username         = $_POST['username'];
                    $nama             = ucwords($_POST['nama']);
                    $afiliasi         = ucwords($_POST['afiliasi']);
                    $negara           = $_POST['negara_afiliasi'] == '' ? '-' : ucwords($_POST['negara_afiliasi']);
                    $alamat           = $_POST['alamat_afiliasi'] == '' ? '-' : ucwords($_POST['alamat_afiliasi']);
                    $url_orcid        = $_POST['url_orcid'] == '' ? '-' : $_POST['url_orcid'];
                    $url_profil       = $_POST['url_profil'] == '' ? '-' : $_POST['url_profil'];
                    $email            = $_POST['email'] == '' ? '-' : $_POST['email'];
                    $hp               = $_POST['hp'] == '' ? '-' : $_POST['hp'];
                    //$password         = md5($_POST['password']);
                    $tglubah          = date("Y/m/d");
                    $image            = "IMAGE_" . $username . ".jpg";
                    $upload           = move_uploaded_file($_FILES['image']['tmp_name'], "../img/presenter/$image");

                    $query_edit = "UPDATE presenter set realname='$nama', email='$email', afiliasi='$afiliasi', negara_afiliasi='$negara', alamat_afiliasi='$alamat',
                url_orcid='$url_orcid', url_profil='$url_profil', no_hp='$hp', image='$image',last_update='$tglubah' WHERE username='$username'";

                    //echo $query_edit;
                    $update = mysqli_query($konek, $query_edit);
                    if ($update) {
                        echo '<script>alert("Profil Pengguna Berhasil di Edit")
                 location.replace("' . $base_url . '/index.php?p=dashboard")</script>';
                    } else {

                        echo '<script>alert("Profil Pengguna Gagal di Edit")
                 location.replace("' . $base_url . '/index.php?p=edit-presenter")</script>';
                    }
                }

                if (isset($_POST['update_pass'])) {
                    $password         = md5($_POST['password']);

                    $query_pas = "UPDATE presenter set password='$password' WHERE username='$username'";
                    $update_pass = mysqli_query($konek, $query_pas);

                    //echo $query_pas;
                    if ($update_pass) {
                        echo '<script>alert("Password Pengguna Berhasil di Ubah")
                 location.replace("' . $base_url . '/index.php?p=dashboard")</script>';
                    } else {

                        echo '<script>alert("Password Pengguna Pengguna Gagal di Ubah")
                 location.replace("' . $base_url . '/index.php?p=edit-presenter")</script>';
                    }
                }
            
            ?>

                <!-- /.box -->

                <!-- Input addon -->


        </div>
    </div>

    </div>
    </div>
    <?php 
    }
    ?> 