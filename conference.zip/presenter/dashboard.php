<?php
if ($_SESSION['group_session'] == 'presenter') {
    ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Upload Paper
    </h1>

</section>
</br>
<!-- Main content -->
<section class="content">
    <div class="row">
        <!-- left column -->
        <div class="col-md-12">
            <div class="callout callout-danger">
                <h4>Peringatan!</h4>
                <li>Berkas Paper Belum Lengkap</li>
                <li>Berkas Belum Di Verifikasi</li>
            </div>
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header with-border">

                </div>

                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-4">

                        </div>
                        <div class="col-md-4">
                            <button type="button" class="btn btn-block btn-warning disabled">Download LoL</button>
                        </div>
                        <div class="col-md-4">

                        </div>
                        <br>
                        <br>

                        <div class="col-md-4">

                        </div>
                        <div class="col-md-4">
                            <button type="button" class="btn btn-block btn-success disabled">Download LoA (Letter of Acceptance)</button>
                        </div>
                        <div class="col-md-4">

                        </div>
                        <br>
                        <br>
                        <div class="col-md-12">

                            <!-- form start -->
                            <div class="box">
                                <div class="box-header">

                                </div>
                                <!-- /.box-header -->
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th style="width: 5%;">NO</th>
                                                <th style="width: 15%;">PENGARANG</th>
                                                <th style="width: 30%;">JUDUL</th>
                                                <th style="width: 20%;">KEYWORD</th>
                                                <th style="width: 10%;">STATUS</th>
                                                <th style="width: 10%;">ACTION</th>
                                            </tr>
                                        </thead>
                                        <?php
                                        $username =  $_SESSION['username'];
                                        $no = 1;

                                        $select_paper = mysqli_query($konek, "SELECT paper.paper_id, paper.judul, presenter.username, presenter.realname, paper.v_paper FROM paper 
                                        LEFT JOIN presenter ON paper.username=presenter.username 
                                        WHERE paper.username='$username'");



                                        while ($row_paper = mysqli_fetch_array($select_paper)) {

                                            $select_keyword = mysqli_query($konek, "SELECT mk.keyword as keyword FROM paper LEFT JOIN paper_keyword as pk ON paper.paper_id=pk.paper_id
                                          LEFT JOIN mst_keyword as mk ON pk.keyword_id=mk.keyword_id WHERE username='$username'");
                                            while ($row_keyword = mysqli_fetch_array($select_keyword)) {

                                                $key = $row_keyword['keyword'];
                                            };

                                            if ($row_paper['v_paper'] == 0) {

                                                $status = '<p style="color: red; font-weight: bold;"> Belum Verifikasi</p>';
                                            } else {

                                                $status = '<p style="color: green; font-weight: bold;">Sudah Verifikasi</p>';
                                            }
                                            echo "<tbody>
                                            <tr>
                                                <td>$no</td>
                                                <td>$row_paper[realname] </td>
                                                <td>$row_paper[judul] </td>                                                
                                                <td>$key</td>
                                                <td>$status</td>
                                                <td><a href='$base_url/index.php?p=edit-paper&id=$row_paper[paper_id]'><button type='button' class='btn btn-default'><i class='fa fa-edit'></i></button></a>
                                                <a href='$base_url/index.php?p=hapus&id=" . $row_paper['paper_id'] . "'onClick=\"return confirm('Apakah anda yakin akan menghapus data Paper $row_paper[judul] ?')\"><button type='button' class='btn btn-default'><i class='fa fa-trash'></i></button></a></td>
                                            </tr>
                                        </tbody>";

                                            $no++;
                                        };
                                        ?>

                                        <tfoot>
                                            <tr>
                                                <th>NO</th>
                                                <th>PENGARANG</th>
                                                <th>JUDUL</th>
                                                <th>KEYWORD</th>
                                                <th>STATUS</th>
                                                <th>ACTION</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.box-body -->
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box -->


            <!-- /.box -->

            <!-- Input addon -->


        </div>
    </div>

    </div>
    </div>
    <?php 
}
?> 