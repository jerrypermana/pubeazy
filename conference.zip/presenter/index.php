<!DOCTYPE html>



<!-- end menu BAR-->

<!--  body -->
<?php
$domain = $_SERVER['SERVER_NAME'];
$base_url = "http://" . $domain . "/conference/presenter";
include "header.php";
if (isset($_GET["p"])) {
  $id = $_GET["p"];

  if ($id == "dashboard") {
    include 'dashboard.php';
  } elseif ($id == "add-paper") {
    include 'paper/add-paper.php';
  } elseif ($id == "edit-paper") {
    include 'paper/edit-paper.php';
  } elseif ($id == "list-paper") {
    include 'paper/list-paper.php';
  } elseif ($id == "edit-presenter") {
    include 'paper/edit-presenter.php';
  } elseif ($id == "hapus") {
    include 'paper/hapus.php';
  }else {
    include 'index.php';
  }
}
include "footer.php"
?>
<!-- End  body -->


<!-- CONTENT-WRAPPER SECTION END--> 