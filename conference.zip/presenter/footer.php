 <!-- AKHIR CONTENT TEMPALTE -->
 </div>
 <!-- /.content-wrapper -->

 <footer class="main-footer">
     <div class="pull-right hidden-xs">

     </div>
     <strong>Copyright &copy; 2019 <a href="https://adminlte.io">PubEazy</a>.</strong>
 </footer>

 <!-- Control Sidebar -->
 <aside class="control-sidebar control-sidebar-dark">
     <!-- Create the tabs -->
     <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
         <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>

         <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
     </ul>


 </aside>
 <!-- /.control-sidebar -->
 <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
 <div class="control-sidebar-bg"></div>
 </div>
 <!-- ./wrapper -->

 
 <!-- Bootstrap 3.3.7 -->
 <script src="../assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
 <!-- SlimScroll -->
 <script src="../assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
 <!-- DataTables -->
 <script src="../assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
 <script src="../assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
 <!-- Select2 -->
 <script src="../assets/bower_components/select2/dist/js/select2.full.min.js"></script>
 <!-- FastClick -->
 <script src="../assets/bower_components/fastclick/lib/fastclick.js"></script>
 <!-- AdminLTE App -->
 <script src="../assets/dist/js/adminlte.min.js"></script>
 <!-- AdminLTE for demo purposes -->
 <script src="../assets/dist/js/demo.js"></script>

 <script>
     $(document).ready(function() {
         


         $('#add_keyword').submit(function(e) {
             data = $('#add_keyword').serialize();
             $.ajax({
                 type: "POST",
                 url: "paper/save-keyword.php",
                 data: data,
                 dataType: "json",
                 success: function(result) {
                     if (result.success) {
                         alert(result.msg);
                         $('#ModalAdd').modal('hide');
                         $('#add_keyword')[0].reset();
                         reload();
                     }
                 }
             });
             e.preventDefault();
         });



         $('.sidebar-menu').tree()
     })

     function reload() {
         document.getElementById('iframeid').src += '';
     }

     $(function() {
         $('#example1').DataTable()
         $('#example2').DataTable({
             'paging': true,
             'lengthChange': false,
             'searching': false,
             'ordering': true,
             'info': true,
             'autoWidth': false
         })
     })
    
    

 </script>


 </body>

 </html> 