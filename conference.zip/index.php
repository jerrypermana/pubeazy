<!DOCTYPE html>

<?php

$domain = $_SERVER['SERVER_NAME'];
$base_url = "http://" .$domain ."/conference" ;

// Include Header website
include "header.php";
// Include Body Website
include "home.php";
//Include Footer Website
include "footer.php";

?>
